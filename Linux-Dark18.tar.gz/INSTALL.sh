#!/bin/bash
cd icons
sudo cp Linux-Dark /usr/share/icons/
cd ..
cd themes
sudo cp Linux-Dark /usr/share/themes/
echo '===================================='
echo ' OK DONE INSTALL SUKSES '
echo '===================================='
